// Simple test program to flash the two LEDs fitted to my demoboard, proves something works.
// Version 1.0
// 12th February 2010
// The first LED is connected to GPIO.2, the second to GPIO.4
// Logic 0 turns on the LED, logic 1 turns off.

#include <system.h>

#pragma DATA _CONFIG, _CPD_OFF & _BODEN_OFF & _MCLRE_ON & _PWRTE_OFF & _WDT_OFF & _INTRC_OSC_NOCLKOUT
#pragma CLOCK_FREQ 4000000 
// Clock frequency of 4 MHz
// Internal frequency is Fosc/4 or 1 MHz.

void main()
{
	ansel = 0; // Disable analogue inputs
	cmcon = 7; // Set GPIO pins as digital
	trisio = 0x00; // Set I/O port 0-4 as outputs. 
	gpio = 1; // Set all outputs to 1, all LEDs off

	while(1)
	{
		gpio.2 = 1;
		gpio.4 = 1;
		delay_ms(250);
		gpio.2 = 0;
		gpio.4 = 1;
		delay_ms(250);
		gpio.2 = 1;
		gpio.4 = 0;
		delay_ms(250);
	}	

}
